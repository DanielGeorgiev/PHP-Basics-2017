<?php

class Son extends Father
{

    //Methods
    public function getGenerationNum(){
        return 2;
    }
}