<?php

class GrandSon extends Son
{

    //Methods
    public function getGenerationNum(){
        return 3;
    }
}