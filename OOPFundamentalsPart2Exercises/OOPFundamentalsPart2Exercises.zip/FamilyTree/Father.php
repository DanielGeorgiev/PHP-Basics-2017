<?php

class Father extends Person
{
    public function getGenerationNum()
    {
        return 1;
    }

}