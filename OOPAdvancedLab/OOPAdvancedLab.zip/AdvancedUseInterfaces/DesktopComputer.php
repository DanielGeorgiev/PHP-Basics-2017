<?php

class DesktopComputer extends ComputerAbstract implements KeyboardInterface, MouseInterface
{
    public function pressKey(string $key)
    {
        // TODO: Implement pressKey() method.
    }

    public function changeStatus()
    {
        // TODO: Implement changeStatus() method.
    }

    public function move($currX, $currY)
    {
        // TODO: Implement move() method.
    }

    public function click($leftClick, $rightClick)
    {
        // TODO: Implement click() method.
    }
}
