<?php

$d = new DesktopComputer();

$l1 = new Laptop();
$l2 = new Laptop();

$t = new Tablet();

$m1 = new MobilePhone();
$m2 = new MobilePhone();
$m3 = new MobilePhone();

$n = new Notebook();