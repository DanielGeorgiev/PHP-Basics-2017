<?php

class MobilePhone extends MobileAbstract implements TouchPadInterface
{
    public function moveFinger()
    {
        // TODO: Implement moveFinger() method.
    }

    public function padClick()
    {
        // TODO: Implement click() method.
    }
}