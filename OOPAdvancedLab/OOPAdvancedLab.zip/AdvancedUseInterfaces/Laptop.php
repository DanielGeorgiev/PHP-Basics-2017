<?php

class Laptop extends ComputerAbstract implements KeyboardInterface, MouseInterface, TouchPadInterface
{
    public function pressKey(string $key)
    {
        // TODO: Implement pressKey() method.
    }

    public function changeStatus()
    {
        // TODO: Implement changeStatus() method.
    }

    public function move($currX, $currY)
    {
        // TODO: Implement move() method.
    }

    public function click($leftClick, $rightClick)
    {

    }

    public function padClick()
    {
        // TODO: Implement padClick() method.
    }

    public function moveFinger()
    {
        // TODO: Implement moveFinger() method.
    }
}