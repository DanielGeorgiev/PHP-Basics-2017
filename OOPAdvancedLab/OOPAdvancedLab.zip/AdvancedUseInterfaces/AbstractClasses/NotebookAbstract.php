<?php

abstract class NotebookAbstract
{
    protected $processor;
    protected $ram;
    protected $operator;
    protected $canCall;
    protected $battery;
    protected $writtenText;
}