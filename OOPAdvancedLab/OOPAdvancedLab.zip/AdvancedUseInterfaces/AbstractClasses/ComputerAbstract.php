<?php

abstract class ComputerAbstract
{
    protected $processor;
    protected $ram;
}