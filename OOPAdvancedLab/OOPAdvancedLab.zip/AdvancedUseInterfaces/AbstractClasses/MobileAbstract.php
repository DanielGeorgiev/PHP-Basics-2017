<?php

abstract class MobileAbstract
{
    protected $operator;
    protected $canCall;
    protected $battery;
}