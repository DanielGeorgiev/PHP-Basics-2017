<?php

interface TouchPadInterface
{
    public function moveFinger();

    public function padClick();
}